import pygame
import random
import cv2
import numpy as np
import threading
import time

def game():
    display_width = 800
    display_height = 600

    pygame.init()
    disp = pygame.display.set_mode((800,600))
    clock = pygame.time.Clock()

    back = pygame.image.load("background.png")
    rect = back.get_rect()
    rect.left, rect.top = [0,0]

    class Item:
        x = 0
        y = 0
        yvel = 0
        image = ""

        def __init__(self,image, x, yvel, y = 600):
            self.x = x
            self.y = y
            self.yvel = yvel
            if image != "pineapple.png" and image != "pear.png":
                image = pygame.image.load(image)
                image = pygame.transform.scale(image, (100, 100))
            else:
                image = pygame.image.load(image)
                image = pygame.transform.scale(image, (70, 120))
            self.image = image
            disp.blit(image, (x, y))

        def move(self, xvel, yacc):
            self.x += xvel
            self.y += self.yvel
            self.yvel += yacc

    crashed = False


    xvel = 4
    yacc = 0.3
    objects = []

    while not crashed:
        
        newi = random.randint(0,200)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                crashed = True


        if newi == 5 :
            objects.append(Item("pineapple.png", random.randint(0, 500), yvel = random.randint(-18,-10)))
        elif newi == 2:
            objects.append(Item("apple.png", random.randint(0, 500), yvel = random.randint(-18,-10)))
        elif newi == 8:
            objects.append(Item("pear.png", random.randint(0, 500), yvel = random.randint(-18,-10)))
        elif newi == 10:
            objects.append(Item("orange.png", random.randint(0, 500), yvel = random.randint(-18,-10)))
        elif newi == 11:
            objects.append(Item("bomb.png", random.randint(0, 500), yvel = random.randint(-18,-10)))
               
        disp.fill((255, 255, 255))
        disp.blit(back, rect)

        for item in objects:
                item.move(xvel, yacc)
                disp.blit(item.image, (item.x, item.y))
                if item.x - 100 > display_width or item.y > 600:
                    objects.remove(item)

        
        pygame.display.update()
        clock.tick(60)
    pygame.quit()

def video():
    cap = cv2.VideoCapture(0)

    while True:
        _, frame = cap.read()

        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        lower = np.array([35, 50, 20])
        upper = np.array([77,255,255])
        mask = cv2.inRange(hsv,lower, upper)

        contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
        cv2.drawContours(frame, contours, -1, (255, 0, 0), 3)

        
        cv2.imshow ("Frame", frame)
        key = cv2.waitKey(1)
        if key == 27:
            break
        time.sleep(0.1)

    cap.release()
    cv2.destroyAllWindows()
        

threading.Thread(target = game).start()

video()


